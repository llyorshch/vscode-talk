package com.example.vscodedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VscodedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VscodedemoApplication.class, args);
	}
}
